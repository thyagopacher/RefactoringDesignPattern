package br.com.padrao;

/**
 * exemplo cavado padr�o para aplicar Strategy
 */
public class MovieTicket {

    private double price;

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double calculate(char type) {
        if(type == 'S'){
			return price * 0.8;
		}else if(type == 'C'){
			return price -10;
		}else if(type == 'M'){
			return price * 0.5;
		}
		return -1;
    }
}
