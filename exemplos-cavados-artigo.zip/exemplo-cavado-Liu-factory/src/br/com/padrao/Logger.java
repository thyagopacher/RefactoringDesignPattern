package br.com.padrao;

/**
 * exemplo cavado padr�o para aplicar Factory
 */
public class Logger{

    public void writeLog() {
        
    }
}
