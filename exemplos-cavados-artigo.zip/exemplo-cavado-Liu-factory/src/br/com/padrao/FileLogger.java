package br.com.padrao;

/**
 * exemplo cavado padr�o para aplicar Factory
 */
public class FileLogger extends Logger {

    public void writeLog() {
        
    }
}
