/**
* Class gerada automaticamente pelo sistema de refatoração - Factory 
* @author - Thyago Henrique Pacher
 *@since 16 de Maio de 2018
 */
package br.com.padrao;

public class FileLoggerFactory extends LoggerFactory {

    public Logger createLogger() {
        return new FileLogger();
    }
}
