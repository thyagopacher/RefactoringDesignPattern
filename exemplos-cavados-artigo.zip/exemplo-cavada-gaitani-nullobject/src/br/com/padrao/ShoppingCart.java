package br.com.padrao;

import java.util.Date;

public class ShoppingCart {
	
	private Customer buyer = null;
	private Order order = null;
	
	public ShoppingCart(Customer customer) {
		setBuyer(customer);
	}

	public void setBuyer(Customer buyer) {
		this.buyer = buyer;
	}
	
	public Customer getBuyer() {
		return buyer;
	}

	public void updateShipmentInfo(String street, String city, String country) {
		Address shipmentAddress = new Address(street, city, country);
		buyer.setShipmentAddress(shipmentAddress);
	}
	
	public double getDiscount() {
		double discount = 0;
		if(buyer != null) {
			discount = buyer.getDiscount();
		}
		return discount;
	}
	
	public void updatePaymentInfo(String creditCard, Date issueDate) throws CustomerNotFoundException{
		if(buyer != null) {
			buyer.setCreditCard(creditCard);
			buyer.setIssueDate(issueDate);
		}else {
			throw new CustomerNotFoundException();
		}
	}
	
	public void placeOrder() throws CustomerNotFoundException{
		if(buyer == null) {
			throw new CustomerNotFoundException();
		}
		order = new Order();
		order.setCustomer(buyer);
	}
}
